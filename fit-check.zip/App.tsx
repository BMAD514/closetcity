/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import StartScreen from './components/StartScreen';
import Canvas from './components/Canvas';
import WardrobePanel from './components/WardrobePanel';
import OutfitStack from './components/OutfitStack';
import ListingPanel from './components/ListingPanel';
import { generateVirtualTryOnImage, generatePoseVariation, generateListingDetails } from './services/geminiService';
import { OutfitLayer, WardrobeItem, Listing } from './types';
import { ChevronDownIcon, ChevronUpIcon, ShirtIcon, TagIcon } from './components/icons';
import { defaultWardrobe } from './wardrobe';
import Footer from './components/Footer';
import { getFriendlyErrorMessage, exportToCSV } from './lib/utils';
import Spinner from './components/Spinner';

const POSE_INSTRUCTIONS = [
  "Frontal View",
  "3/4 View",
  "Side Profile",
  "Back View"
];

const useMediaQuery = (query: string): boolean => {
  const [matches, setMatches] = useState(() => window.matchMedia(query).matches);

  useEffect(() => {
    const mediaQueryList = window.matchMedia(query);
    const listener = (event: MediaQueryListEvent) => setMatches(event.matches);
    mediaQueryList.addEventListener('change', listener);
    if (mediaQueryList.matches !== matches) {
      setMatches(mediaQueryList.matches);
    }
    return () => {
      mediaQueryList.removeEventListener('change', listener);
    };
  }, [query, matches]);

  return matches;
};


const App: React.FC = () => {
  const [modelImageUrl, setModelImageUrl] = useState<string | null>(null);
  const [outfitHistory, setOutfitHistory] = useState<OutfitLayer[]>([]);
  const [currentOutfitIndex, setCurrentOutfitIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [currentPoseIndex, setCurrentPoseIndex] = useState(0);
  const [isSheetCollapsed, setIsSheetCollapsed] = useState(false);
  const [wardrobe, setWardrobe] = useState<WardrobeItem[]>(defaultWardrobe);
  
  // New state for selling functionality
  const [viewMode, setViewMode] = useState<'styling' | 'sell'>('styling');
  const [activeListing, setActiveListing] = useState<Listing | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);

  const isMobile = useMediaQuery('(max-width: 767px)');

  const activeOutfitLayers = useMemo(() => 
    outfitHistory.slice(0, currentOutfitIndex + 1), 
    [outfitHistory, currentOutfitIndex]
  );
  
  const activeGarmentIds = useMemo(() => 
    activeOutfitLayers.map(layer => layer.garment?.id).filter(Boolean) as string[], 
    [activeOutfitLayers]
  );
  
  const displayImageUrl = useMemo(() => {
    if (outfitHistory.length === 0) return modelImageUrl;
    const currentLayer = outfitHistory[currentOutfitIndex];
    if (!currentLayer) return modelImageUrl;

    const poseInstruction = POSE_INSTRUCTIONS[currentPoseIndex];
    return currentLayer.poseImages[poseInstruction] ?? Object.values(currentLayer.poseImages)[0];
  }, [outfitHistory, currentOutfitIndex, currentPoseIndex, modelImageUrl]);

  const availablePoseKeys = useMemo(() => {
    if (outfitHistory.length === 0) return [];
    const currentLayer = outfitHistory[currentOutfitIndex];
    return currentLayer ? Object.keys(currentLayer.poseImages) : [];
  }, [outfitHistory, currentOutfitIndex]);

  const handleModelFinalized = (url: string) => {
    setModelImageUrl(url);
    setOutfitHistory([{
      garment: null,
      poseImages: { [POSE_INSTRUCTIONS[0]]: url }
    }]);
    setCurrentOutfitIndex(0);
  };

  const handleStartOver = () => {
    setModelImageUrl(null);
    setOutfitHistory([]);
    setCurrentOutfitIndex(0);
    setIsLoading(false);
    setLoadingMessage('');
    setError(null);
    setCurrentPoseIndex(0);
    setIsSheetCollapsed(false);
    setWardrobe(defaultWardrobe);
    setViewMode('styling');
    setActiveListing(null);
  };

  const handleGarmentSelect = useCallback(async (garmentFile: File, garmentInfo: WardrobeItem) => {
    if (!displayImageUrl || isLoading) return;

    const nextLayer = outfitHistory[currentOutfitIndex + 1];
    if (nextLayer && nextLayer.garment?.id === garmentInfo.id) {
        setCurrentOutfitIndex(prev => prev + 1);
        setCurrentPoseIndex(0);
        return;
    }

    setError(null);
    setIsLoading(true);
    setLoadingMessage(`Adding ${garmentInfo.name}...`);

    try {
      const newImageUrl = await generateVirtualTryOnImage(displayImageUrl, garmentFile);
      const newLayer: OutfitLayer = { 
        garment: garmentInfo, 
        poseImages: { [POSE_INSTRUCTIONS[0]]: newImageUrl } 
      };

      setOutfitHistory(prevHistory => {
        const newHistory = prevHistory.slice(0, currentOutfitIndex + 1);
        return [...newHistory, newLayer];
      });
      setCurrentOutfitIndex(prev => prev + 1);
      setCurrentPoseIndex(0);
      
      setWardrobe(prev => {
        if (prev.find(item => item.id === garmentInfo.id)) return prev;
        return [...prev, garmentInfo];
      });
    } catch (err) {
      setError(getFriendlyErrorMessage(err, 'Failed to apply garment'));
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [displayImageUrl, isLoading, outfitHistory, currentOutfitIndex]);

  const handleRemoveLastGarment = () => {
    if (currentOutfitIndex > 0) {
      setCurrentOutfitIndex(prevIndex => prevIndex - 1);
      setCurrentPoseIndex(0);
    }
  };
  
  const handlePoseSelect = useCallback(async (newIndex: number) => {
    if (isLoading || outfitHistory.length === 0 || newIndex === currentPoseIndex) return;
    
    const poseInstruction = POSE_INSTRUCTIONS[newIndex];
    const currentLayer = outfitHistory[currentOutfitIndex];

    if (currentLayer.poseImages[poseInstruction]) {
      setCurrentPoseIndex(newIndex);
      return;
    }

    // Always use the frontal view image as the source for generating new poses for consistency.
    const baseImageForPoseChange = currentLayer.poseImages[POSE_INSTRUCTIONS[0]];
    if (!baseImageForPoseChange) {
        setError("Cannot change pose: the base frontal view image for this outfit is missing.");
        return;
    }

    setError(null);
    setIsLoading(true);
    setLoadingMessage(`Changing pose to ${poseInstruction}...`);
    
    const prevPoseIndex = currentPoseIndex;
    setCurrentPoseIndex(newIndex);

    try {
      const newImageUrl = await generatePoseVariation(baseImageForPoseChange, poseInstruction);
      setOutfitHistory(prevHistory => {
        const newHistory = [...prevHistory];
        const updatedLayer = newHistory[currentOutfitIndex];
        updatedLayer.poseImages[poseInstruction] = newImageUrl;
        return newHistory;
      });
    } catch (err) {
      setError(getFriendlyErrorMessage(err, 'Failed to change pose'));
      setCurrentPoseIndex(prevPoseIndex);
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [currentPoseIndex, outfitHistory, isLoading, currentOutfitIndex]);

  // --- Selling Functions ---
  const handleStartSelling = () => {
    if (!displayImageUrl) return;
    const newListing: Listing = {
      id: `listing-${Date.now()}`,
      title: '',
      brand: '',
      size: '',
      condition: 'Excellent',
      price: 0,
      description: '',
      altText: '',
      imageUrl: displayImageUrl,
      modelId: 'model-123'
    };
    setActiveListing(newListing);
    setViewMode('sell');
  };

  const handleUpdateListing = (updatedListing: Listing) => {
    setActiveListing(updatedListing);
  };

  const handleSaveListing = () => {
    if (!activeListing) return;
    setListings(prev => {
      const existingIndex = prev.findIndex(l => l.id === activeListing.id);
      if (existingIndex > -1) {
        const newListings = [...prev];
        newListings[existingIndex] = activeListing;
        return newListings;
      }
      return [...prev, activeListing];
    });
    // In a real app, you'd show a success message.
    alert('Listing saved!');
  };

  const handleGenerateDescription = async () => {
    if (!activeListing || !activeListing.imageUrl) return;
    
    setIsLoading(true);
    setLoadingMessage('Generating AI description...');
    setError(null);
    
    try {
        const { description, altText } = await generateListingDetails(activeListing.imageUrl, {
            brand: activeListing.brand,
            title: activeListing.title,
        });
        setActiveListing(prev => prev ? { ...prev, description, altText } : null);
    } catch (err) {
        setError(getFriendlyErrorMessage(err, 'Failed to generate description'));
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleExportListings = () => {
    if (listings.length === 0) {
      alert("No saved listings to export.");
      return;
    }
    exportToCSV(listings, 'resale_listings.csv');
  };

  const viewVariants = {
    initial: { opacity: 0, y: 15 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -15 },
  };

  const panelContent = useMemo(() => {
    if (viewMode === 'styling') {
      return (
        <>
          <OutfitStack 
            outfitHistory={activeOutfitLayers}
            onRemoveLastGarment={handleRemoveLastGarment}
            onStartSelling={handleStartSelling}
          />
          <WardrobePanel
            onGarmentSelect={handleGarmentSelect}
            activeGarmentIds={activeGarmentIds}
            isLoading={isLoading}
            wardrobe={wardrobe}
          />
        </>
      );
    }
    if (viewMode === 'sell') {
      return activeListing ? (
        <ListingPanel 
          listing={activeListing}
          onListingUpdate={handleUpdateListing}
          onGenerateDescription={handleGenerateDescription}
          onSaveListing={handleSaveListing}
          onExport={handleExportListings}
        />
      ) : null;
    }
  }, [viewMode, activeOutfitLayers, handleRemoveLastGarment, handleStartSelling, handleGarmentSelect, activeGarmentIds, isLoading, wardrobe, activeListing, handleUpdateListing, handleGenerateDescription, handleSaveListing, handleExportListings]);

  return (
    <div className="font-sans">
      <AnimatePresence mode="wait">
        {!modelImageUrl ? (
          <motion.div
            key="start-screen"
            className="w-screen min-h-screen flex items-start sm:items-center justify-center bg-gray-50 p-4 pb-20"
            variants={viewVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={{ duration: 0.5, ease: 'easeInOut' }}
          >
            <StartScreen onModelFinalized={handleModelFinalized} />
          </motion.div>
        ) : (
          <motion.div
            key="main-app"
            className="relative flex flex-col h-screen bg-white overflow-hidden"
            variants={viewVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={{ duration: 0.5, ease: 'easeInOut' }}
          >
            <main className="flex-grow relative flex flex-col md:flex-row overflow-hidden">
              <div className="w-full h-full flex-grow flex items-center justify-center bg-white pb-16 relative">
                <Canvas 
                  displayImageUrl={displayImageUrl}
                  onStartOver={handleStartOver}
                  isLoading={isLoading}
                  loadingMessage={loadingMessage}
                  onSelectPose={handlePoseSelect}
                  poseInstructions={POSE_INSTRUCTIONS}
                  currentPoseIndex={currentPoseIndex}
                  availablePoseKeys={availablePoseKeys}
                  isSellMode={viewMode === 'sell'}
                />
              </div>

              <aside 
                className={`absolute md:relative md:flex-shrink-0 bottom-0 right-0 h-auto md:h-full w-full md:w-1/3 md:max-w-sm bg-white/80 backdrop-blur-md flex flex-col border-t md:border-t-0 md:border-l border-gray-200/60 transition-transform duration-500 ease-in-out ${isSheetCollapsed ? 'translate-y-[calc(100%-4.5rem)]' : 'translate-y-0'} md:translate-y-0`}
                style={{ transitionProperty: 'transform' }}
              >
                  <button 
                    onClick={() => setIsSheetCollapsed(!isSheetCollapsed)} 
                    className="md:hidden w-full h-8 flex items-center justify-center bg-gray-100/50"
                    aria-label={isSheetCollapsed ? 'Expand panel' : 'Collapse panel'}
                  >
                    {isSheetCollapsed ? <ChevronUpIcon className="w-6 h-6 text-gray-500" /> : <ChevronDownIcon className="w-6 h-6 text-gray-500" />}
                  </button>
                  
                  {/* View Mode Toggle */}
                  <div className="flex-shrink-0 p-2 bg-gray-50 border-b border-gray-200/60">
                    <div className="grid grid-cols-2 gap-2 bg-gray-200/80 p-1 rounded-md">
                      <button onClick={() => setViewMode('styling')} className={`flex items-center justify-center gap-2 text-sm font-semibold py-1.5 rounded-md transition-colors ${viewMode === 'styling' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:bg-white/50'}`}>
                        <ShirtIcon className="w-4 h-4" /> Styling
                      </button>
                      <button onClick={handleStartSelling} className={`flex items-center justify-center gap-2 text-sm font-semibold py-1.5 rounded-md transition-colors ${viewMode === 'sell' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:bg-white/50'}`}>
                        <TagIcon className="w-4 h-4" /> Sell
                      </button>
                    </div>
                  </div>

                  <div className="p-4 md:p-6 pb-20 overflow-y-auto flex-grow flex flex-col gap-8">
                    {error && (
                      <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
                        <p className="font-bold">Error</p>
                        <p>{error}</p>
                      </div>
                    )}
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={viewMode}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                        className="flex flex-col gap-8"
                      >
                        {panelContent}
                      </motion.div>
                    </AnimatePresence>
                  </div>
              </aside>
            </main>
            <AnimatePresence>
              {isLoading && isMobile && (
                <motion.div
                  className="fixed inset-0 bg-white/80 backdrop-blur-md flex flex-col items-center justify-center z-50"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <Spinner />
                  {loadingMessage && (
                    <p className="text-lg font-serif text-gray-700 mt-4 text-center px-4">{loadingMessage}</p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
      <Footer isOnDressingScreen={!!modelImageUrl} />
    </div>
  );
};

export default App;