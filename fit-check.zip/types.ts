/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export interface WardrobeItem {
  id: string;
  name: string;
  url: string;
}

export interface OutfitLayer {
  garment: WardrobeItem | null; // null represents the base model layer
  poseImages: Record<string, string>; // Maps pose instruction to image URL
}

// --- New Types for Resale Functionality ---

export type ListingCondition = 'New with Tags' | 'Excellent' | 'Good' | 'Fair';

export interface Listing {
  id: string;
  modelId: string;
  imageUrl: string;
  title: string;
  brand: string;
  size: string;
  condition: ListingCondition;
  price: number;
  description: string;
  altText: string;
}