/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { Listing, ListingCondition } from '../types';

interface ListingFormProps {
  listing: Listing;
  onListingUpdate: (listing: Listing) => void;
  onGenerateDescription: () => void;
  isLoading: boolean;
}

const conditionOptions: ListingCondition[] = ['New with Tags', 'Excellent', 'Good', 'Fair'];

const ListingForm: React.FC<ListingFormProps> = ({ listing, onListingUpdate, onGenerateDescription, isLoading }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    onListingUpdate({
      ...listing,
      [name]: name === 'price' ? parseFloat(value) || 0 : value,
    });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-serif tracking-wider text-gray-800">Listing Details</h3>
      
      <div>
        <label htmlFor="brand" className="block text-sm font-medium text-gray-700">Brand</label>
        <input type="text" name="brand" id="brand" value={listing.brand} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder="e.g., Acme Corp" />
      </div>
      
      <div>
        <label htmlFor="title" className="block text-sm font-medium text-gray-700">Title</label>
        <input type="text" name="title" id="title" value={listing.title} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder="e.g., Vintage Denim Jacket" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="size" className="block text-sm font-medium text-gray-700">Size</label>
          <input type="text" name="size" id="size" value={listing.size} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder="e.g., Medium" />
        </div>
        <div>
          <label htmlFor="condition" className="block text-sm font-medium text-gray-700">Condition</label>
          <select id="condition" name="condition" value={listing.condition} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm">
            {conditionOptions.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="price" className="block text-sm font-medium text-gray-700">Price ($)</label>
        <input type="number" name="price" id="price" value={listing.price} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder="e.g., 49.99" />
      </div>

      <div>
        <div className="flex justify-between items-center mb-1">
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
            <button onClick={onGenerateDescription} disabled={isLoading} className="text-xs font-semibold text-gray-600 hover:text-gray-900 disabled:opacity-50">✨ Auto-generate</button>
        </div>
        <textarea id="description" name="description" rows={4} value={listing.description} onChange={handleChange} className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-gray-500 focus:border-gray-500 sm:text-sm" placeholder="A detailed description of the item..."></textarea>
      </div>

    </div>
  );
};

export default ListingForm;