/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { Listing } from '../types';
import ListingForm from './ListingForm';

interface ListingPanelProps {
  listing: Listing;
  onListingUpdate: (listing: Listing) => void;
  onGenerateDescription: () => void;
  onSaveListing: () => void;
  onExport: () => void;
}

const ListingPanel: React.FC<ListingPanelProps> = ({ 
  listing, 
  onListingUpdate, 
  onGenerateDescription,
  onSaveListing,
  onExport
}) => {
  const isFormValid = listing.title && listing.brand && listing.price > 0;

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h2 className="text-xl font-serif tracking-wider text-gray-800 border-b border-gray-400/50 pb-2 mb-4">Create Resale Listing</h2>
        <div className="flex items-center gap-4">
            <img src={listing.imageUrl} alt="Outfit to sell" className="w-20 h-20 rounded-md object-cover border" />
            <div className="flex-grow">
                <p className="font-bold text-gray-800">{listing.title || 'Untitled Listing'}</p>
                <p className="text-sm text-gray-600">{listing.brand || 'No brand'}</p>
                <p className="text-lg font-semibold text-gray-900 mt-1">${listing.price.toFixed(2)}</p>
            </div>
        </div>
      </div>
      
      <ListingForm 
        listing={listing}
        onListingUpdate={onListingUpdate}
        onGenerateDescription={onGenerateDescription}
        isLoading={false} // This can be wired to a specific loading state if needed
      />

      <div className="pt-6 border-t border-gray-400/50 space-y-3">
        <h3 className="text-lg font-serif tracking-wider text-gray-800">Actions</h3>
        <button
            onClick={onSaveListing}
            disabled={!isFormValid}
            className="w-full text-center bg-gray-900 text-white font-semibold py-2.5 px-4 rounded-lg transition-colors duration-200 ease-in-out hover:bg-gray-700 active:scale-95 text-base disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
            Save Listing
        </button>
        <button
            onClick={onExport}
            className="w-full text-center bg-white border border-gray-300 text-gray-700 font-semibold py-2.5 px-4 rounded-lg transition-all duration-200 ease-in-out hover:bg-gray-100 hover:border-gray-400 active:scale-95 text-base"
        >
            Export for Poshmark/eBay (CSV)
        </button>
        <div className="grid grid-cols-2 gap-3 pt-2">
            <button className="w-full text-center bg-blue-600 text-white font-semibold py-2.5 px-4 rounded-lg transition-colors duration-200 ease-in-out hover:bg-blue-700 active:scale-95 text-base">Buy Now</button>
            <button className="w-full text-center bg-gray-200 text-gray-800 font-semibold py-2.5 px-4 rounded-lg transition-colors duration-200 ease-in-out hover:bg-gray-300 active:scale-95 text-base">Make Offer</button>
        </div>
      </div>
    </div>
  );
};

export default ListingPanel;